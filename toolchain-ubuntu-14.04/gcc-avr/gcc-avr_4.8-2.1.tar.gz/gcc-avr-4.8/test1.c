main() {int a,b; return a*b;}
