#include <stream.h>
main() {cout << "Hi!\n";}
